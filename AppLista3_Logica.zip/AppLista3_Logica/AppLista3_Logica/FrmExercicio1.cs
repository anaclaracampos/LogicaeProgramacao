﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista3_Logica
{
    public partial class FrmExercicio1 : Form
    {
        public FrmExercicio1()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            float xuxuzinho = float.Parse(txtNum1.Text.ToString());
            float xuxuzinho1 = float.Parse(txtNum2.Text.ToString());

            float xuxuzinho2 = float.Parse(txtNum3.Text.ToString());

            float resultado = xuxuzinho + xuxuzinho1 + xuxuzinho2;

            MessageBox.Show(""+resultado);

        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            float Num1 = float.Parse(txtNum1.Text);
            float Num2 = float.Parse(txtNum2.Text);
            float Num3 = float.Parse(txtNum3.Text);
            float media;

            //media
            media = Num1 + Num2 + Num3;
            MessageBox.Show("O resultado da média é: " + media);
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float porc1;
            float porc2;
            float porc3;

            porc1 = num1 / (num1 + num2 + num3) * 100;
            porc2 = num2 / (num1 + num2 + num3) * 100;
            porc3 = num3 / (num1 + num2 + num3) * 100;

            MessageBox.Show("Porcentagem do NUM 1: " + porc1 + "; Porcentagem do NUM 2: " + porc2 + "; Porcentagem do NUM 3: " + porc3);

        }

  
    }
}
