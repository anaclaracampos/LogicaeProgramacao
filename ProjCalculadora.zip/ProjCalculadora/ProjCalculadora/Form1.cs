﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjCalculadora
{
    public partial class FormCalculadora : Form
    {
        public FormCalculadora()
        {
            InitializeComponent();
        }

        

       

        private void btnsoma_Click(object sender, EventArgs e)
        {
            float varN1 = float.Parse(txtN1.Text);
            float varN2 = float.Parse(txtN2.Text);
            float resultado;

            //soma

            resultado = varN1 + varN2;
            MessageBox.Show("O resultado da soma é: " + resultado);
        }

        private void btnsubtra_Click(object sender, EventArgs e)
        {
            float varN1 = float.Parse(txtN1.Text);
            float varN2 = float.Parse(txtN1.Text);
            float resultado;

            //subtração

            resultado = varN1 - varN2;
            MessageBox.Show("O reultado da subtração é: " + resultado);

        }

        private void btnmutip_Click(object sender, EventArgs e)
        {
            float varN1 = float.Parse(txtN1.Text);
            float varN2 = float.Parse(txtN2.Text);
            float resultado;

            //multiplicação

            resultado = varN1 * varN2;
            MessageBox.Show("O resultado de multiplicação é: " + resultado);

        }

        private void btndivisao_Click(object sender, EventArgs e)
        {
            float varN1 = float.Parse(txtN1.Text);
            float varN2 = float.Parse(txtN2.Text);
            float resultado;

            //divisão

            resultado = varN1 / varN2;
            MessageBox.Show("O resultado da divisão é: " + resultado);
        }
    }
}
