﻿namespace ProjCalculadora
{
    partial class FormCalculadora
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnsoma = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnsubtra = new System.Windows.Forms.Button();
            this.btndivisao = new System.Windows.Forms.Button();
            this.btnmutip = new System.Windows.Forms.Button();
            this.lblN1 = new System.Windows.Forms.Label();
            this.txtN1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtN2 = new System.Windows.Forms.TextBox();
            this.lblN2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(173, 178);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 4;
            // 
            // btnsoma
            // 
            this.btnsoma.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsoma.Location = new System.Drawing.Point(152, 291);
            this.btnsoma.Name = "btnsoma";
            this.btnsoma.Size = new System.Drawing.Size(84, 65);
            this.btnsoma.TabIndex = 1;
            this.btnsoma.Text = "+";
            this.btnsoma.Click += new System.EventHandler(this.btnsoma_Click);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(173, 178);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(173, 178);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 23);
            this.label3.TabIndex = 10;
            // 
            // btnsubtra
            // 
            this.btnsubtra.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsubtra.Location = new System.Drawing.Point(274, 291);
            this.btnsubtra.Name = "btnsubtra";
            this.btnsubtra.Size = new System.Drawing.Size(84, 65);
            this.btnsubtra.TabIndex = 5;
            this.btnsubtra.Text = "-";
            this.btnsubtra.Click += new System.EventHandler(this.btnsubtra_Click);
            // 
            // btndivisao
            // 
            this.btndivisao.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndivisao.Location = new System.Drawing.Point(517, 291);
            this.btndivisao.Name = "btndivisao";
            this.btndivisao.Size = new System.Drawing.Size(84, 65);
            this.btndivisao.TabIndex = 7;
            this.btndivisao.Text = "/";
            this.btndivisao.Click += new System.EventHandler(this.btndivisao_Click);
            // 
            // btnmutip
            // 
            this.btnmutip.Font = new System.Drawing.Font("Palatino Linotype", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmutip.Location = new System.Drawing.Point(395, 291);
            this.btnmutip.Name = "btnmutip";
            this.btnmutip.Size = new System.Drawing.Size(84, 65);
            this.btnmutip.TabIndex = 6;
            this.btnmutip.Text = "*";
            this.btnmutip.Click += new System.EventHandler(this.btnmutip_Click);
            // 
            // lblN1
            // 
            this.lblN1.AutoSize = true;
            this.lblN1.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblN1.Location = new System.Drawing.Point(168, 92);
            this.lblN1.Name = "lblN1";
            this.lblN1.Size = new System.Drawing.Size(110, 28);
            this.lblN1.TabIndex = 8;
            this.lblN1.Text = "Número 1";
            // 
            // txtN1
            // 
            this.txtN1.Location = new System.Drawing.Point(173, 123);
            this.txtN1.Name = "txtN1";
            this.txtN1.Size = new System.Drawing.Size(100, 20);
            this.txtN1.TabIndex = 9;
//            this.txtN1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(173, 178);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 23);
            this.label5.TabIndex = 1;
            // 
            // txtN2
            // 
            this.txtN2.Location = new System.Drawing.Point(173, 204);
            this.txtN2.Name = "txtN2";
            this.txtN2.Size = new System.Drawing.Size(100, 20);
            this.txtN2.TabIndex = 13;
            // 
            // lblN2
            // 
            this.lblN2.AutoSize = true;
            this.lblN2.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblN2.Location = new System.Drawing.Point(168, 173);
            this.lblN2.Name = "lblN2";
            this.lblN2.Size = new System.Drawing.Size(110, 28);
            this.lblN2.TabIndex = 12;
            this.lblN2.Text = "Número 2";
            // 
            // FormCalculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtN2);
            this.Controls.Add(this.lblN2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtN1);
            this.Controls.Add(this.lblN1);
            this.Controls.Add(this.btndivisao);
            this.Controls.Add(this.btnmutip);
            this.Controls.Add(this.btnsubtra);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnsoma);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormCalculadora";
            this.Text = "Calculadora";
//            this.Load += new System.EventHandler(this.FormCalculadora_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnsoma;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnsubtra;
        private System.Windows.Forms.Button btndivisao;
        private System.Windows.Forms.Button btnmutip;
        private System.Windows.Forms.Label lblN1;
        private System.Windows.Forms.TextBox txtN1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtN2;
        private System.Windows.Forms.Label lblN2;
    }
}

